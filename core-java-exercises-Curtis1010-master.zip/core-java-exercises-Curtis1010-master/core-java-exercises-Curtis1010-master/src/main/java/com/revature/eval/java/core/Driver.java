package com.revature.eval.java.core;

import java.util.Scanner;



public class Driver {
	
	public static Scanner userInput = new Scanner(System.in);
	
	public static void main(String[] args) {
	
		EvaluationService evaluationService = new EvaluationService();
		
		
		System.out.println("Enter a choice for exercise");
		System.out.println("1. Reverse String");
		System.out.println("2. Turn string into acronym");
		System.out.println("3. Check for triangle type");
		System.out.println("4. Get Scrabble Score");
		System.out.println("5. Clean phone number");
		System.out.println("6. Count words in phase");
		System.out.println("7. String to pig latin");
		System.out.println("8. Check if number is a armstrong number");
		System.out.println("9. Check if the number is prime factor");
		System.out.println("10. Getting the nth prime factor number");
		System.out.println("11. ISBN-10 verification");
		System.out.println("12. Check for pangram");
		System.out.println("13. Check for Luhn algorithm");
		String choice = userInput.nextLine();
		
		switch (choice) {
		
		case "1":
			//reverse string
			System.out.println("Enter a Word");
			String Word = userInput.nextLine();
			System.out.println(evaluationService.reverse(Word));
			
			break;
			
		case "2":
			//turn string into Acronym
			System.out.println("Enter a Acronym");
			String phrase = userInput.nextLine();
			System.out.println(evaluationService.acronym(phrase));
			break;
			
		case "3":
			//Triangle
			evaluationService.tri.Display();
			break;
			
		case "4":
			//get scrabble score
			System.out.println("Enter a word <Must be all CAPS>");
			String WordS = userInput.nextLine();
			System.out.println(evaluationService.getScrabbleScore(WordS));
			break;

		case "5":
			//clean phone number
			System.out.println("Enter a phone number");
			String Phone = userInput.nextLine();
			evaluationService.cleanPhoneNumber(Phone);
			break;
			
		case "6":
			//count words in phrase
			System.out.println("Enter a Phrase");
			String Cphrase = userInput.nextLine();
			evaluationService.wordCount(Cphrase);
			break;
			
		case "7":
			//enter a word to turn into piglatin
			System.out.println("Enter a word");
			String pig = userInput.nextLine();
			System.out.println(evaluationService.toPigLatin(pig));
			
			break;
			
		case "8":
			//check if number is a armstrong number
			 System.out.println("Ënter 3 Digit Number");
			 int  num = userInput.nextInt();
			 evaluationService.isArmstrongNumber(num);
			break;
			
		case "9":
			//checking if number is a primefactor
			 System.out.println("Ënter a Number");
			 long  l = userInput.nextInt();
			 System.out.println(evaluationService.calculatePrimeFactorsOf(l));
			break;

		case "10":
			//getting the nth prime number
			 System.out.println("Ënter a Number");
			 long  n = userInput.nextInt();
			 evaluationService.calculateNthPrime(n);
			break;
			
			
		case "11":
			//The ISBN-10 verification process
			System.out.println("Enter a ISBN");
			String isbn = userInput.nextLine();
			 if (evaluationService.isValidIsbn(isbn)) 
		            System.out.print("Valid"); 
		        else
		            System.out.print("Invalid"); 
			break;
			
		case "12":
			//check for pangram
			System.out.println("Enter a sentence");
			String str = userInput.nextLine();
		
	        if (evaluationService.isPangram(str) == true) 
	            System.out.println("is a pangram"); 
	        else
	            System.out.println("is not a pangram"); 
	        
			break;
			
		case "13":
			//The Luhn algorithm
			System.out.println("Enter a card number");
			String cardNo = userInput.nextLine(); 
	        if (evaluationService.isLuhnValid(cardNo))
	            System.out.println("This is a valid card"); 
	        else
	            System.out.println("This is not a valid card"); 
	        
			break;
			
			
		default:
			break;
		}
		
		
	}
	

}
